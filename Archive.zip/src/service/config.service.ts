import { Injectable } from '@angular/core';

@Injectable()
export class Config {
	constructor() {}
	set(name:string, value:any){
		this[name] = value;
	}
}