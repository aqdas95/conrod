import { NgModule } from '@angular/core';
import { CrossSellComponent } from './cross-sell/cross-sell';
@NgModule({
	declarations: [CrossSellComponent],
	imports: [],
	exports: [CrossSellComponent]
})
export class ComponentsModule {}
