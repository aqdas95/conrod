export class DataSet
{
    smsSend                     : string;
    appSecret                   : string;
    providerRefCommando         : string;
    providerRefReseller         : string;
    providerRefDealer           : string;
    constructor()
    {
        this.smsSend                    = "18768224788";
        this.appSecret                  = "cD32-dcDWxc]253c=sw@Efcfhp}";
        this.providerRefCommando        = "CRC000000001";
        this.providerRefReseller        = "RRC000000023";
        this.providerRefDealer          = "DRC000000001";
    }
}